package com.example.resistorlab.adapter

import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.resistorlab.data.response.BandDetail
import com.example.resistorlab.databinding.ItemBandDetailBinding

class BandDetailAdapter(private val bandDetails: List<BandDetail>) : RecyclerView.Adapter<BandDetailAdapter.ViewHolder>() {

    private val colorMap = mapOf(
        "black" to Color.BLACK,
        "brown" to Color.parseColor("#A52A2A"),
        "red" to Color.RED,
        "orange" to Color.parseColor("#FFA500"),
        "yellow" to Color.YELLOW,
        "green" to Color.GREEN,
        "blue" to Color.BLUE,
        "violet" to Color.parseColor("#8A2BE2"),
        "gray" to Color.GRAY,
        "white" to Color.WHITE,
        "gold" to Color.parseColor("#FFD700"),
        "silver" to Color.parseColor("#C0C0C0")
    )

    private val colorToValueMap = mapOf(
        "black" to "0", "brown" to "1", "red" to "2", "orange" to "3",
        "yellow" to "4", "green" to "5", "blue" to "6", "violet" to "7",
        "gray" to "8", "white" to "9", "gold" to "10%", "silver" to "20%"
    )

    private fun getValueForColor(color: String): String {
        return colorToValueMap[color] ?: "Unknown Value"
    }

    inner class ViewHolder(val binding: ItemBandDetailBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemBandDetailBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val detail = bandDetails[position]
        holder.binding.tvBandColor.text = detail.color
        holder.binding.tvBandValue.text = getValueForColor(detail.color)

        val color = colorMap[detail.color] ?: Color.TRANSPARENT
        holder.binding.ivColorCircle.setImageDrawable(createColorCircleDrawable(color))
    }

    override fun getItemCount() = bandDetails.size

    private fun createColorCircleDrawable(color: Int): GradientDrawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(color)
            setSize(24, 24)
        }
    }
}
