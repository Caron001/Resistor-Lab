package com.example.resistorlab.view.result

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.graphics.drawable.toBitmap
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.resistorlab.R
import com.example.resistorlab.adapter.BandDetailAdapter
import com.example.resistorlab.data.response.BandDetail
import com.example.resistorlab.databinding.ActivityResultBinding
import com.example.resistorlab.di.ResistorColorDetectorHelper
import org.tensorflow.lite.task.gms.vision.detector.Detection

class ResultActivity : AppCompatActivity(), ResistorColorDetectorHelper.DetectorListener {
    private lateinit var binding: ActivityResultBinding
    private lateinit var objectDetectorHelper: ResistorColorDetectorHelper

    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityResultBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val imageUri = intent.getStringExtra(EXTRA_IMAGE_URI)?.let { Uri.parse(it) }

        if (imageUri != null) {
            binding.imgResistor.setImageURI(imageUri)
            initializeObjectDetector(imageUri)
        } else {
            binding.imgResistor.visibility = View.GONE
            Toast.makeText(this, getString(R.string.error_image), Toast.LENGTH_SHORT).show()
        }
    }

    private fun initializeObjectDetector(imageUri: Uri) {
        Log.d(TAG, "Image URI: $imageUri")
        objectDetectorHelper = ResistorColorDetectorHelper(
            context = this,
            detectorListener = this
        )
        Handler(Looper.getMainLooper()).postDelayed({
            if (objectDetectorHelper.isTfLiteVisionInitialized) {
                objectDetectorHelper.detectObjectIfReady(imageUri)
            } else {
                onError(getString(R.string.tflitevision_is_not_initialized_yet))
            }
        }, 500)
    }

    private fun showLoading(isLoading: Boolean) {
        binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
    }

    override fun onResults(results: MutableList<Detection>?, inferenceTime: Long, imageHeight: Int, imageWidth: Int) {
        showLoading(false)
        if (results.isNullOrEmpty()) {
            runOnUiThread {
                Toast.makeText(this@ResultActivity, "No resistor detected", Toast.LENGTH_SHORT).show()
            }
        } else {
            showLoading(true)
            val resistorDetails = results.map { detection ->
                val label = detection.categories.firstOrNull()?.label ?: "Unknown"
                val score = detection.categories.firstOrNull()?.score ?: 0f
                val boundingBox = detection.boundingBox

                drawBoundingBox(boundingBox, label, score)

                BandDetail(color = label, value = getValueForColor(label))
            }
            updateUIWithResistorDetails(resistorDetails)
            showLoading(false)
        }
    }

    override fun onError(error: String) {
        Toast.makeText(this@ResultActivity, error, Toast.LENGTH_SHORT).show()
    }

    private fun drawBoundingBox(boundingBox: RectF, label: String, score: Float) {
        val drawable = binding.imgResistor.drawable ?: return
        val imageView = binding.imgResistor

        val intrinsicWidth = drawable.intrinsicWidth
        val intrinsicHeight = drawable.intrinsicHeight

        val imageViewWidth = imageView.width
        val imageViewHeight = imageView.height

        val scaleX = imageViewWidth.toFloat() / intrinsicWidth
        val scaleY = imageViewHeight.toFloat() / intrinsicHeight
        val scale = scaleX.coerceAtMost(scaleY)

        val offsetX = (imageViewWidth - intrinsicWidth * scale) / 2
        val offsetY = (imageViewHeight - intrinsicHeight * scale) / 2

        val transformedBoundingBox = RectF(
            boundingBox.left * scale + offsetX,
            boundingBox.top * scale + offsetY,
            boundingBox.right * scale + offsetX,
            boundingBox.bottom * scale + offsetY
        )

        val bitmap = drawable.toBitmap().copy(Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(bitmap)
        val paintBox = Paint().apply {
            color = Color.RED
            strokeWidth = 5f
            style = Paint.Style.STROKE
        }
        val paintText = Paint().apply {
            color = Color.WHITE
            textSize = 30f
            typeface = Typeface.DEFAULT_BOLD
            style = Paint.Style.FILL
            isAntiAlias = true
        }
        canvas.drawRect(transformedBoundingBox, paintBox)

        val labelText = "$label: ${"%.2f".format(score)}"
        canvas.drawText(labelText, transformedBoundingBox.left, transformedBoundingBox.top - 10, paintText)

        binding.imgResistor.setImageBitmap(bitmap)
    }

    private fun getValueForColor(color: String): String {
        val colorToValueMap = mapOf(
            "black" to "0", "brown" to "1", "red" to "2", "orange" to "3",
            "yellow" to "4", "green" to "5", "blue" to "6", "violet" to "7",
            "gray" to "8", "white" to "9", "gold" to "10%", "silver" to "20%"
        )
        return colorToValueMap[color] ?: "Unknown Value"
    }

    private fun updateUIWithResistorDetails(resistorDetails: List<BandDetail>) {
        val adapter = BandDetailAdapter(resistorDetails)
        binding.rvColorDetails.layoutManager = LinearLayoutManager(this)
        binding.rvColorDetails.adapter = adapter
    }

    companion object {
        const val EXTRA_IMAGE_URI = "extra_image_uri"
        private const val TAG = "ResultActivity"
    }
}