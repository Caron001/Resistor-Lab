package com.example.resistorlab.data.response

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class BandDetail(
    val color: String,
    val value: String
) : Parcelable