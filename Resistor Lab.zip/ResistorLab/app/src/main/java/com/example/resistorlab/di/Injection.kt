package com.example.resistorlab.di

import android.content.Context
import com.example.resistorlab.data.UserRepository
import com.example.resistorlab.data.pref.UserPreference
import com.example.resistorlab.data.pref.dataStore
import com.example.resistorlab.data.retrofit.ApiConfig

object Injection {
    fun provideRepository(context: Context): UserRepository {
        val pref = UserPreference.getInstance(context.dataStore)
        val apiService = ApiConfig.getApiService()
        return UserRepository.getInstance(pref, apiService)
    }
}