package com.example.resistorlab.view.material

import androidx.lifecycle.*
import com.example.resistorlab.data.UserRepository
import com.example.resistorlab.data.response.DataItem
import kotlinx.coroutines.launch

class MaterialViewModel(private val repository: UserRepository) : ViewModel() {

    private val _materials = MutableLiveData<List<DataItem>>()
    val materials: LiveData<List<DataItem>> = _materials
    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading
    private val _errorMessage = MutableLiveData<String?>()
    val errorMessage: LiveData<String?> = _errorMessage

    fun fetchMaterials() {
        _isLoading.value = true
        viewModelScope.launch {
            try {
                val response = repository.getMaterial()
                _materials.value = response.data?.filterNotNull() ?: emptyList()
                _errorMessage.value = null
            } catch (e: Exception) {
                _errorMessage.value = e.localizedMessage
            } finally {
                _isLoading.value = false
            }
        }
    }
}