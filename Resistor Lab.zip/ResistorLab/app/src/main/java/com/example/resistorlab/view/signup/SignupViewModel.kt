package com.example.resistorlab.view.signup

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.resistorlab.R
import com.example.resistorlab.data.UserRepository
import kotlinx.coroutines.launch
import retrofit2.HttpException

class SignupViewModel(private val repository: UserRepository) : ViewModel() {

    fun register(username: String, email: String, password: String, onResult: (Int) -> Unit) {
        viewModelScope.launch {
            try {
                repository.register(username, email, password)
                onResult(R.string.message_register_succeed)
            } catch (e: HttpException) {
                val errorBody = e.response()?.errorBody()?.string()
                Log.e("SignupViewModel", "HttpException: $errorBody")
                val message = when {
                    errorBody?.contains("Email is already taken", ignoreCase = true) == true -> {
                        R.string.message_email_taken
                    }
                    else -> R.string.message_general_error
                }
                onResult(message)
            } catch (e: Exception) {
                Log.e("SignupViewModel", "Exception: ${e.message}")
                onResult(R.string.message_general_error)
            }
        }
    }
}