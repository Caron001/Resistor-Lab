package com.example.resistorlab.view.login

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.resistorlab.R
import com.example.resistorlab.data.UserRepository
import com.example.resistorlab.data.pref.UserModel
import kotlinx.coroutines.launch
import retrofit2.HttpException

class LoginViewModel(private val repository: UserRepository) : ViewModel() {
    fun login(email: String, password: String, onResult: (Int) -> Unit) {
        viewModelScope.launch {
            try {
                val response = repository.login(email, password)
                val token = response.loginResult?.token
                if (token != null) {
                    val user = UserModel(email, token)
                    repository.saveSession(user)
                    onResult(R.string.message_login_succeed)
                } else {
                    onResult(R.string.message_login_failed)
                }
            } catch (e: HttpException) {
                val errorBody = e.response()?.errorBody()?.string()
                Log.e("LoginViewModel", "HttpException: $errorBody")
                val message = when {
                    errorBody?.contains("Invalid credentials", ignoreCase = true) == true -> {
                        R.string.message_invalid_credentials
                    }
                    else -> {
                        R.string.message_general_error
                    }
                }
                onResult(message)
            } catch (e: Exception) {
                Log.e("LoginViewModel", "Exception: ${e.message}")
                onResult(R.string.message_general_error)
            }
        }
    }
}