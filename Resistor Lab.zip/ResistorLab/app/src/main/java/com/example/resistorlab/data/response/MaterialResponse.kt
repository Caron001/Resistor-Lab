package com.example.resistorlab.data.response

import com.google.gson.annotations.SerializedName

data class MaterialResponse(

	@field:SerializedName("data")
	val data: List<DataItem?>? = null,

	@field:SerializedName("message")
	val message: String? = null
)

data class ImagesItem(

	@field:SerializedName("id")
	val id: String? = null,

	@field:SerializedName("url_image")
	val urlImage: String? = null
)

data class DataItem(

	@field:SerializedName("images")
	val images: List<ImagesItem?>? = null,

	@field:SerializedName("id")
	val id: String? = null,

	@field:SerializedName("title")
	val title: String? = null,

	@field:SerializedName("content")
	val content: String? = null
)
