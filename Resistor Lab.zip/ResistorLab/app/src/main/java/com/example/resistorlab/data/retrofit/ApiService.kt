package com.example.resistorlab.data.retrofit

import com.example.resistorlab.data.response.LoginResponse
import com.example.resistorlab.data.response.MaterialResponse
import com.example.resistorlab.data.response.RegisterResponse
import retrofit2.http.*

interface ApiService {
    @FormUrlEncoded
    @POST("register")
    suspend fun register(
        @Field("username") username: String,
        @Field("email") email: String,
        @Field("password") password: String
    ): RegisterResponse

    @FormUrlEncoded
    @POST("login")
    suspend fun login(
        @Field("email") email: String,
        @Field("password") password: String
    ): LoginResponse

    @GET("material")
    suspend fun getMaterial(): MaterialResponse
}
