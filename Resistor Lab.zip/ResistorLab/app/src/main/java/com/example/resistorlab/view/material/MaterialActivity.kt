package com.example.resistorlab.view.material

import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.resistorlab.adapter.MaterialAdapter
import com.example.resistorlab.databinding.ActivityMaterialBinding
import com.example.resistorlab.view.ViewModelFactory

class MaterialActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMaterialBinding
    private val materialViewModel by viewModels<MaterialViewModel> {
        ViewModelFactory.getInstance(this)
    }
    private lateinit var materialAdapter: MaterialAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMaterialBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupRecyclerView()
        observeViewModel()

        materialViewModel.fetchMaterials()
    }

    private fun setupRecyclerView() {
        materialAdapter = MaterialAdapter()
        binding.rvMaterials.apply {
            layoutManager = LinearLayoutManager(this@MaterialActivity)
            adapter = materialAdapter
        }
    }

    private fun observeViewModel() {
        materialViewModel.materials.observe(this) { materials ->
            materials?.let {
                materialAdapter.submitList(it)
            }
        }

        materialViewModel.isLoading.observe(this) { isLoading ->
            binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
        }

        materialViewModel.errorMessage.observe(this) { message ->
            if (!message.isNullOrEmpty()) {
                Toast.makeText(this@MaterialActivity, message, Toast.LENGTH_SHORT).show()
            }
        }
    }
}